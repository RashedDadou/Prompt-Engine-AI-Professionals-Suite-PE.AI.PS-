import cv2
import numpy as np
import PyOpenGL as gl
import os
import asyncio
from datetime import datetime

class AIImageAssistant:
    def __init__(self):
        self.generation_memory = []
        self.engine_performance = {
            "plasma_engine": {"response_rate": 80, "issues": []},
            "laser_weapon": {"response_rate": 50, "issues": []},
            "ion_engine": {"response_rate": 30, "issues": []}
        }
        self.engine = pyttsx3.init()  # For dynamic sound
        self.progress_callback = None  # For GUI updates

    def set_progress_callback(self, callback):
        """Set a callback function for GUI progress updates."""
        self.progress_callback = callback

    async def refresh_memory(self, input_data):
        print("Image Assistant: Refreshing generation memory...")
        self.generation_memory.append(input_data)
        self.generation_memory = self.generation_memory[-3:]
        return self.generation_memory

    async def generate_image(self, text, knowledge_lib, hd_level='1080p', export_format="both"):
        print(f"Image Assistant: Generating image for - {text} in {hd_level}")
        
        engine_type = "plasma_engine" if "plasma" in text else "ion_engine" if "ion" in text else "laser_weapon" if "laser" in text else None
        response_rate = self.engine_performance.get(engine_type, {"response_rate": 80})["response_rate"] if engine_type else 80
        issues = []
        
        resolution = (1920, 1080) if hd_level == '1080p' else (1280, 720) if hd_level == '720p' else (640, 480)
        
        if "engines" in text and "15 degrees" not in text:
            issues.append("Engine alignment issue")
            return {"output": "error: Engine alignment issue", "issues": issues}
        
        if "plasma engines" in text:
            knowledge_lib.update_knowledge("spacecraft", "engines", "plasma_thrust", "10")
            knowledge_lib.update_knowledge("spacecraft", "engines", "plasma_angle", "15")
        if "laser" in text:
            knowledge_lib.update_knowledge("engineering", "weapons", "laser_power", "500 MW")
        
        try:
            # Attempt Unreal Engine rendering
            renderer = unreal.get_engine().get_renderer()
            renderer.set_use_gpu(True)
            renderer.set_use_nanite(True)
            world = unreal.get_editor_subsystem(unreal.EditorLevelLibrary).get_world()
            actor = unreal.EditorLevelLibrary.spawn_actor_from_class(unreal.StaticMeshActor, unreal.Vector(0, 0, 0))
            if "plasma" in text:
                material = unreal.MaterialInterface.load('/Game/Materials/PlasmaMaterial')
                actor.set_material(0, material)
            elif "laser" in text:
                material = unreal.MaterialInterface.load('/Game/Materials/LaserMaterial')
                actor.set_material(0, material)
            output = f"3D Image generated with {'15-degree engine alignment' if 'engines' in text else 'specified components'} in {hd_level}"
        except Exception as e:
            issues.append(f"Unreal Engine rendering error: {str(e)}")
            output = "error: 3D rendering failed"
        
        if response_rate < 100:
            issues.append(f"Current 3D engine response rate: {response_rate}%")
            await self.optimize_engine_performance(engine_type or "plasma_engine")
            if response_rate < 85:
                output += " (supplemented with manual drawing)"
                await self.add_manual_drawing(text, resolution, export_format)
        
        if "spacecraft" in text:
            try:
                SetupUtility.setup_blenderproc()
                bpy.ops.export_scene.obj(filepath="spacecraft_model.obj", use_selection=True)
                print("Exported 3D model to spacecraft_model.obj")
                self.engine.say("Spacecraft ready for launch.")
                self.engine.runAndWait()
            except Exception as e:
                issues.append(f"Blender export error: {str(e)}")
        
        return {"output": output, "issues": issues}

    async def optimize_engine_performance(self, engine_type):
        print(f"Image Assistant: Optimizing 3D engine for {engine_type}...")
        current_rate = self.engine_performance[engine_type]["response_rate"]
        new_rate = min(current_rate + 20, 100)
        self.engine_performance[engine_type]["response_rate"] = new_rate
        self.engine_performance[engine_type]["issues"].append(f"Improved response rate to {new_rate}%")

    async def add_manual_drawing(self, text, resolution=(1920, 1080), export_format="both"):
        print(f"Image Assistant: Adding manual drawing with PyOpenGL at {resolution}...")
        try:
            gl.glViewport(0, 0, resolution[0], resolution[1])
            gl.glClear(gl.GL_COLOR_BUFFER_BIT | gl.GL_DEPTH_BUFFER_BIT)
            
            scale_factor = resolution[0] / 1280
            frames = []
            asteroid_x = 100 * scale_factor
            thruster_intensity = 0.5  # For dynamic thruster glow
            
            for frame in range(120):  # 5 seconds at 24 FPS
                gl.glClear(gl.GL_COLOR_BUFFER_BIT | gl.GL_DEPTH_BUFFER_BIT)
                
                # Update progress in GUI
                if self.progress_callback:
                    self.progress_callback(f"Rendering frame {frame + 1}/120")
                
                # Spacecraft hull
                gl.glColor3f(0.0, 0.0, 1.0)  # Blue hull
                gl.glBegin(gl.GL_LINE_LOOP)
                for i in range(360):
                    angle = i * 3.14159 / 180
                    x = 400 * scale_factor + 400 * scale_factor * np.cos(angle)
                    y = 600 * scale_factor + 400 * scale_factor * np.sin(angle)
                    gl.glVertex2f(x, y)
                gl.glEnd()
                
                # Thruster glow (dynamic effect)
                if "plasma" in text or "engines" in text:
                    gl.glColor3f(1.0, 0.5, thruster_intensity)  # Orange glow
                    gl.glBegin(gl.GL_TRIANGLE_FAN)
                    gl.glVertex2f(400 * scale_factor, 200 * scale_factor)  # Thruster base
                    for i in range(360):
                        angle = i * 3.14159 / 180
                        x = 400 * scale_factor + 100 * scale_factor * np.cos(angle)
                        y = 200 * scale_factor + 100 * scale_factor * np.sin(angle)
                        gl.glVertex2f(x, y)
                    gl.glEnd()
                    thruster_intensity = 0.5 + 0.3 * np.sin(frame * 0.1)  # Pulsating effect
                
                # Commander perspective
                gl.glColor3f(0.5, 0.5, 0.5)
                gl.glBegin(gl.GL_QUADS)
                gl.glVertex2f(1200 * scale_factor, 400 * scale_factor)
                gl.glVertex2f(1800 * scale_factor, 400 * scale_factor)
                gl.glVertex2f(1800 * scale_factor, 800 * scale_factor)
                gl.glVertex2f(1200 * scale_factor, 800 * scale_factor)
                gl.glEnd()
                gl.glColor3f(1.0, 1.0, 1.0)
                gl.glBegin(gl.GL_LINE_LOOP)
                for i in range(360):
                    angle = i * 3.14159 / 180
                    x = 1300 * scale_factor + 50 * scale_factor * np.cos(angle)
                    y = 500 * scale_factor + 50 * scale_factor * np.sin(angle)
                    gl.glVertex2f(x, y)
                gl.glEnd()
                
                # Asteroid with smooth movement
                asteroid_x += 5 * scale_factor
                if asteroid_x > resolution[0]:
                    asteroid_x = 100 * scale_factor
                gl.glColor3f(0.5, 0.5, 0.5)
                gl.glBegin(gl.GL_LINE_LOOP)
                for i in range(360):
                    angle = i * 3.14159 / 180
                    x = asteroid_x + 75 * scale_factor * np.cos(angle)
                    y = 125 * scale_factor + 75 * scale_factor * np.sin(angle)
                    gl.glVertex2f(x, y)
                gl.glEnd()
                gl.glColor3f(0.6, 0.4, 0.2)
                gl.glBegin(gl.GL_LINES)
                gl.glVertex2f(asteroid_x + 75 * scale_factor, 125 * scale_factor)
                gl.glVertex2f(asteroid_x + 125 * scale_factor, 175 * scale_factor)
                gl.glEnd()
                
                # Capture frame
                img = gl.glReadPixels(0, 0, resolution[0], resolution[1], gl.GL_RGB, gl.GL_UNSIGNED_BYTE)
                img = np.frombuffer(img, dtype=np.uint8).reshape(resolution[1], resolution[0], 3)[::-1]
                frames.append(img)
            
            # Export with error handling
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            if export_format in ["image", "both"]:
                try:
                    cv2.imwrite(f'manual_drawing_hd_{timestamp}.png', frames[0])
                    print(f"Saved static image as 'manual_drawing_hd_{timestamp}.png'")
                except Exception as e:
                    print(f"Error saving image: {str(e)}")
            if export_format in ["video", "both"]:
                try:
                    out = cv2.VideoWriter(f'manual_drawing_video_{timestamp}.mp4', cv2.VideoWriter_fourcc(*'mp4v'), 24, (resolution[0], resolution[1]))
                    for frame in frames:
                        out.write(frame)
                    out.release()
                    print(f"Saved video as 'manual_drawing_video_{timestamp}.mp4'")
                except Exception as e:
                    print(f"Error saving video: {str(e)}")
            
        except Exception as e:
            print(f"OpenGL rendering error: {str(e)}")
            return {"output": "error: OpenGL rendering failed", "issues": [str(e)]}
        
        return {"output": f"Manual drawing completed at {resolution} with thruster glow and asteroid animation", "issues": []}

    async def adjust_manually(self, image_result, resolution=(1280, 720)):
        print("Image Assistant: Applying manual adjustment...")
        if "error" in image_result["output"]:
            if "engine" in image_result["output"]:
                await self.add_manual_drawing("engine nozzle", resolution, export_format="image")
                return "Image adjusted manually with corrected 15-degree engine alignment and hand-drawn nozzle in HD"
        return image_result["output"]