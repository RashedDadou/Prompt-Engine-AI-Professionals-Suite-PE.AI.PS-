import re
import random
import requests
from datetime import datetime

class AIGenerator:
    def __init__(self):
        self.design_patterns = {
            "combat": {
                "hull_color": "#ff0000",
                "thruster_intensity": 0.8,
                "asteroid_speed": 7,
                "weapon_enabled": True,
                "shield_enabled": True,
                "design_features": ["laser cannons", "reinforced armor"]
            },
            "exploration": {
                "hull_color": "#00ff00",
                "thruster_intensity": 0.5,
                "asteroid_speed": 5,
                "weapon_enabled": False,
                "shield_enabled": True,
                "design_features": ["sensor arrays", "lightweight hull"]
            },
            "stealth": {
                "hull_color": "#000000",
                "thruster_intensity": 0.3,
                "asteroid_speed": 3,
                "weapon_enabled": True,
                "shield_enabled": False,
                "design_features": ["cloaking device", "silent thrusters"]
            }
        }

    def generate_design(self, text):
        design_type = "exploration"
        if re.search(r"قتالية|combat|fighter", text, re.IGNORECASE):
            design_type = "combat"
        elif re.search(r"استكشاف|exploration", text, re.IGNORECASE):
            design_type = "exploration"
        elif re.search(r"تخفي|stealth", text, re.IGNORECASE):
            design_type = "stealth"
        
        base_design = self.design_patterns[design_type]
        design = {
            "hull_color": base_design["hull_color"],
            "thruster_intensity": base_design["thruster_intensity"] + random.uniform(-0.1, 0.1),
            "asteroid_speed": base_design["asteroid_speed"] + random.randint(-1, 1),
            "resolution": "1080p",
            "weapon_enabled": base_design["weapon_enabled"],
            "shield_enabled": base_design["shield_enabled"],
            "design_features": base_design["design_features"]
        }
        return design

    def save_design(self, design, server_url="http://localhost:5000"):
        try:
            response = requests.post(f"{server_url}/update_config", json=design)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            with open(f"generated_design_{timestamp}.json", "w") as f:
                json.dump(design, f, indent=4)
            return response.json().get("message", "خطأ في حفظ التصميم") + f"، تم حفظ التصميم في generated_design_{timestamp}.json"
        except Exception as e:
            return f"خطأ في الاتصال بالخادم: {str(e)}"

if __name__ == "__main__":
    generator = AIGenerator()
    design = generator.generate_design("صورة لمركبة فضائية قتالية")
    print(f"التصميم المولد: {design}")
    print(generator.save_design(design))