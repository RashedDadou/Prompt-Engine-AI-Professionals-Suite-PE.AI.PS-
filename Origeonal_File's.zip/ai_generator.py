import re
import random

class AIGenerator:
    def __init__(self):
        self.design_patterns = {
            "combat": {"hull_color": "#ff0000", "weapon_enabled": True, "shield_enabled": True},
            "exploration": {"hull_color": "#00ff00", "weapon_enabled": False, "shield_enabled": True},
            "stealth": {"hull_color": "#000000", "weapon_enabled": True, "shield_enabled": False}
        }

    def generate_design(self, text):
        design_type = "exploration"
        if "قتالية" in text:
            design_type = "combat"
        elif "استكشاف" in text:
            design_type = "exploration"
        elif "تخفي" in text:
            design_type = "stealth"
        
        base_design = self.design_patterns[design_type]
        design = {
            "hull_color": base_design["hull_color"],
            "thruster_intensity": random.uniform(0.3, 0.8),
            "asteroid_speed": random.randint(3, 8),
            "resolution": "1080p",
            "weapon_enabled": base_design["weapon_enabled"],
            "shield_enabled": base_design["shield_enabled"]
        }
        return design

    def save_design(self, design, server_url="http://localhost:5000"):
        try:
            import requests
            response = requests.post(f"{server_url}/update_config", json=design)
            return response.json().get("message", "خطأ في حفظ التصميم")
        except Exception as e:
            return f"خطأ في الاتصال بالخادم: {str(e)}"

if __name__ == "__main__":
    generator = AIGenerator()
    design = generator.generate_design("صورة لمركبة فضائية قتالية")
    print(f"Generated design: {design}")
    print(generator.save_design(design))