import re
import random
import requests
from datetime import datetime

class AIGenerator:
    def __init__(self):
        self.design_patterns = {
            "combat": {
                "hull_color": "#ff0000",
                "thruster_intensity": 0.8,
                "asteroid_speed": 7,
                "weapon_enabled": True,
                "shield_enabled": True,
                "design_features": ["laser cannons", "reinforced armor"],
                "stable_diffusion_prompt": "A futuristic combat spaceship with a sleek red hull, glowing orange thrusters, laser cannons, and a glowing cyan energy shield, set against a starry space background, highly detailed, cinematic lighting"
            },
            "exploration": {
                "hull_color": "#00ff00",
                "thruster_intensity": 0.5,
                "asteroid_speed": 5,
                "weapon_enabled": False,
                "shield_enabled": True,
                "design_features": ["sensor arrays", "lightweight hull"],
                "stable_diffusion_prompt": "A green exploration spaceship with lightweight hull, glowing thrusters, and sensor arrays, in a nebula-filled space background, detailed and vibrant"
            },
            "stealth": {
                "hull_color": "#000000",
                "thruster_intensity": 0.3,
                "asteroid_speed": 3,
                "weapon_enabled": True,
                "shield_enabled": False,
                "design_features": ["cloaking device", "silent thrusters"],
                "stable_diffusion_prompt": "A stealth black spaceship with silent thrusters and laser weapons, partially cloaked, in a dark space background with faint stars"
            }
        }

    def generate_design(self, text):
        design_type = "exploration"
        if re.search(r"قتالية|combat|fighter", text, re.IGNORECASE):
            design_type = "combat"
        elif re.search(r"استكشاف|exploration", text, re.IGNORECASE):
            design_type = "exploration"
        elif re.search(r"تخفي|stealth", text, re.IGNORECASE):
            design_type = "stealth"
        
        base_design = self.design_patterns[design_type]
        design = {
            "hull_color": base_design["hull_color"],
            "thruster_intensity": base_design["thruster_intensity"] + random.uniform(-0.1, 0.1),
            "asteroid_speed": base_design["asteroid_speed"] + random.randint(-1, 1),
            "resolution": "1080p",
            "weapon_enabled": base_design["weapon_enabled"],
            "shield_enabled": base_design["shield_enabled"],
            "design_features": base_design["design_features"],
            "stable_diffusion_prompt": base_design["stable_diffusion_prompt"]
        }
        return design

    def generate_image_with_api(self, prompt, server_url="http://localhost:5000"):
        # محاكاة طلب Stable Diffusion API
        try:
            # في التطبيق الحقيقي، استبدل هذا بطلب API إلى https://x.ai/api
            print(f"محاكاة طلب Stable Diffusion مع الوصف: {prompt}")
            return {
                "status": "success",
                "image_description": f"تم إنشاء صورة بناءً على: {prompt}. الصورة تظهر مركبة فضائية قتالية حمراء مع مدافع ليزر ودرع طاقة سماوي، مضاءة بإضاءة سينمائية على خلفية نجمية."
            }
        except Exception as e:
            return {"status": "error", "message": f"خطأ في طلب API: {str(e)}"}

    def save_design(self, design, server_url="http://localhost:5000"):
        try:
            response = requests.post(f"{server_url}/update_config", json=design)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            with open(f"generated_design_{timestamp}.json", "w") as f:
                json.dump(design, f, indent=4)
            image_response = self.generate_image_with_api(design["stable_diffusion_prompt"], server_url)
            return {
                "config_message": response.json().get("message", "خطأ في حفظ التصميم") + f"، تم حفظ التصميم في generated_design_{timestamp}.json",
                "image_message": image_response
            }
        except Exception as e:
            return {"config_message": f"خطأ في الاتصال بالخادم: {str(e)}", "image_message": {"status": "error", "message": str(e)}}

if __name__ == "__main__":
    generator = AIGenerator()
    design = generator.generate_design("صورة لمركبة فضائية قتالية")
    print(f"التصميم المولد: {design}")
    result = generator.save_design(design)
    print(f"نتيجة الحفظ: {result['config_message']}")
    print(f"نتيجة الصورة: {result['image_message']}")