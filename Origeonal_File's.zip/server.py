from flask import Flask, request, jsonify
import json
from datetime import datetime

app = Flask(__name__)

# مخزن مؤقت للإعدادات
config = {
    "hull_color": "#0000ff",
    "thruster_intensity": 0.5,
    "asteroid_speed": 5,
    "resolution": "1080p",
    "weapon_enabled": False,
    "shield_enabled": False
}

@app.route('/update_config', methods=['POST'])
def update_config():
    data = request.json
    config.update(data)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    with open(f"spacecraft_config_{timestamp}.json", "w") as f:
        json.dump(config, f, indent=4)
    return jsonify({"status": "success", "message": f"Configuration saved to spacecraft_config_{timestamp}.json"})

@app.route('/get_config', methods=['GET'])
def get_config():
    return jsonify(config)

@app.route('/progress', methods=['POST'])
def update_progress():
    data = request.json
    print(f"Progress update: {data['message']}")
    return jsonify({"status": "success"})

if __name__ == "__main__":
    app.run(debug=True, port=5000)