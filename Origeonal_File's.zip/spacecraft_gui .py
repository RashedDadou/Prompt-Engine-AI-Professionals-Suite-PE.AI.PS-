import tkinter as tk
from tkinter import colorchooser, ttk
import json
from datetime import datetime

class SpacecraftGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Spacecraft Customization Panel")
        self.config = {
            "hull_color": "#0000ff",
            "thruster_intensity": 0.5,
            "asteroid_speed": 5,
            "resolution": "1080p"
        }
        
        # GUI Elements
        tk.Label(self.root, text="Spacecraft Customization").pack(pady=10)
        
        # Hull Color
        tk.Button(self.root, text="Choose Hull Color", command=self.choose_hull_color).pack(pady=5)
        
        # Thruster Intensity
        tk.Label(self.root, text="Thruster Intensity").pack()
        self.thruster_scale = tk.Scale(self.root, from_=0, to=1, resolution=0.1, orient=tk.HORIZONTAL)
        self.thruster_scale.set(self.config["thruster_intensity"])
        self.thruster_scale.pack()
        
        # Asteroid Speed
        tk.Label(self.root, text="Asteroid Speed").pack()
        self.asteroid_scale = tk.Scale(self.root, from_=1, to=10, resolution=1, orient=tk.HORIZONTAL)
        self.asteroid_scale.set(self.config["asteroid_speed"])
        self.asteroid_scale.pack()
        
        # Resolution Selection
        tk.Label(self.root, text="Resolution").pack()
        self.resolution_var = tk.StringVar(value="1080p")
        ttk.Combobox(self.root, textvariable=self.resolution_var, values=["480p", "720p", "1080p"]).pack()
        
        # Save Config
        tk.Button(self.root, text="Save Configuration", command=self.save_config).pack(pady=10)
        
        # Progress Label
        self.progress_label = tk.Label(self.root, text="Ready")
        self.progress_label.pack(pady=5)

    def choose_hull_color(self):
        color = colorchooser.askcolor(title="Choose Hull Color")[1]
        if color:
            self.config["hull_color"] = color
            self.progress_label.config(text=f"Selected hull color: {color}")

    def save_config(self):
        self.config["thruster_intensity"] = self.thruster_scale.get()
        self.config["asteroid_speed"] = self.asteroid_scale.get()
        self.config["resolution"] = self.resolution_var.get()
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        with open(f"spacecraft_config_{timestamp}.json", "w") as f:
            json.dump(self.config, f, indent=4)
        self.progress_label.config(text=f"Saved config to spacecraft_config_{timestamp}.json")

    def set_progress(self, message):
        self.progress_label.config(text=message)

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    gui = SpacecraftGUI()
    gui.run()