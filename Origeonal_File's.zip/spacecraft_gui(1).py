import tkinter as tk
from tkinter import colorchooser, ttk
import requests
import json
from datetime import datetime

class SpacecraftGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Spacecraft Customization Panel")
        self.config = {
            "hull_color": "#0000ff",
            "thruster_intensity": 0.5,
            "asteroid_speed": 5,
            "resolution": "1080p",
            "weapon_enabled": False,
            "shield_enabled": False
        }
        self.server_url = "http://localhost:5000"
        
        # GUI Elements
        tk.Label(self.root, text="تخصيص المركبة الفضائية").pack(pady=10)
        
        # Hull Color
        tk.Button(self.root, text="اختيار لون الهيكل", command=self.choose_hull_color).pack(pady=5)
        
        # Thruster Intensity
        tk.Label(self.root, text="كثافة الدافع").pack()
        self.thruster_scale = tk.Scale(self.root, from_=0, to=1, resolution=0.1, orient=tk.HORIZONTAL)
        self.thruster_scale.set(self.config["thruster_intensity"])
        self.thruster_scale.pack()
        
        # Asteroid Speed
        tk.Label(self.root, text="سرعة الكويكب").pack()
        self.asteroid_scale = tk.Scale(self.root, from_=1, to=10, resolution=1, orient=tk.HORIZONTAL)
        self.asteroid_scale.set(self.config["asteroid_speed"])
        self.asteroid_scale.pack()
        
        # Resolution Selection
        tk.Label(self.root, text="الدقة").pack()
        self.resolution_var = tk.StringVar(value="1080p")
        ttk.Combobox(self.root, textvariable=self.resolution_var, values=["480p", "720p", "1080p"]).pack()
        
        # Weapon Toggle
        self.weapon_var = tk.BooleanVar()
        tk.Checkbutton(self.root, text="تفعيل الأسلحة", variable=self.weapon_var).pack()
        
        # Shield Toggle
        self.shield_var = tk.BooleanVar()
        tk.Checkbutton(self.root, text="تفعيل الدروع", variable=self.shield_var).pack()
        
        # Save Config
        tk.Button(self.root, text="حفظ الإعدادات", command=self.save_config).pack(pady=10)
        
        # Progress Label
        self.progress_label = tk.Label(self.root, text="جاهز")
        self.progress_label.pack(pady=5)

    def choose_hull_color(self):
        color = colorchooser.askcolor(title="اختيار لون الهيكل")[1]
        if color:
            self.config["hull_color"] = color
            self.progress_label.config(text=f"تم اختيار لون الهيكل: {color}")
            self.save_config()

    def save_config(self):
        self.config.update({
            "thruster_intensity": self.thruster_scale.get(),
            "asteroid_speed": self.asteroid_scale.get(),
            "resolution": self.resolution_var.get(),
            "weapon_enabled": self.weapon_var.get(),
            "shield_enabled": self.shield_var.get()
        })
        try:
            response = requests.post(f"{self.server_url}/update_config", json=self.config)
            self.progress_label.config(text=response.json().get("message", "خطأ في حفظ الإعدادات"))
        except Exception as e:
            self.progress_label.config(text=f"خطأ في الاتصال بالخادم: {str(e)}")

    def set_progress(self, message):
        self.progress_label.config(text=message)

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    gui = SpacecraftGUI()
    gui.run()