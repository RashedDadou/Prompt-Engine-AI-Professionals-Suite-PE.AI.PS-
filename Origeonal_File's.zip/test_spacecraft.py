import unittest
import requests
import json
from ai_generator import AIGenerator

class TestSpacecraftSystem(unittest.TestCase):
    def setUp(self):
        self.server_url = "http://localhost:5000"
        self.generator = AIGenerator()

    def test_server_config_update(self):
        config = {"hull_color": "#ff0000", "thruster_intensity": 0.7}
        response = requests.post(f"{self.server_url}/update_config", json=config)
        self.assertEqual(response.status_code, 200)
        self.assertIn("success", response.json())

    def test_server_config_retrieval(self):
        response = requests.get(f"{self.server_url}/get_config")
        self.assertEqual(response.status_code, 200)
        config = response.json()
        self.assertIn("hull_color", config)

    def test_ai_generator(self):
        design = self.generator.generate_design("صورة لمركبة فضائية قتالية")
        self.assertEqual(design["hull_color"], "#ff0000")
        self.assertTrue(design["weapon_enabled"])
        self.assertTrue(design["shield_enabled"])

if __name__ == "__main__":
    unittest.main()